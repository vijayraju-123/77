Project Demo : https://euphonious-hotteok-b19557.netlify.app/ 

Project Video : https://www.youtube.com/watch?v=STs8FKWuBz4&ab_channel=GorkCoder 

![screencapture-euphonious-hotteok-b19557-netlify-app-2023-06-18-13_08_37](https://github.com/sunil9813/News-Website/assets/67497228/277ad325-61e0-47b3-91a1-ec914d2b0b78)
